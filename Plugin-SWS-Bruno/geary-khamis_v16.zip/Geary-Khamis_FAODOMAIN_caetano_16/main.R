# This plugin calculates the International Dollar Prices and Purchasing Power Parities
# for a set of countries and items.

# Packages

library(faosws)
library(faoswsUtil)
library(data.table)

if(CheckDebug()){
  
  library(faoswsModules)
  sett <- ReadSettings("modules/geary_khamis/sws.yml")
  
  SetClientFiles(sett$certdir)
  GetTestEnvironment(sett$server, sett$token)
  files = dir("R", full.names = TRUE)
  invisible(sapply(files, source))
}

dataset_ <- swsContext.datasets[[1]]@dataset

# Parameters: 

# Min year
min_year <- as.numeric(swsContext.computationParams$min_year)
# Max year
max_year <- as.numeric(swsContext.computationParams$max_year)
# Base year for the average international dollar price (5540)
base_year <- swsContext.computationParams$base_year
time_range <- (as.numeric(base_year)-1):(as.numeric(base_year)+1)
# Reference country code
reference_country <- swsContext.computationParams$reference_country_code_m49

# Conditions
if(min_year >= base_year){
  stop('The Minimum year must be less than the Base year.')
}

if(max_year <= base_year){
  stop('The Maximum year must be greater than the Base year.')
}

# Reference list of countries

country_list <- ReadDatatable('country_list_for_gk', where = "geographic_area_m49 != 'NA'")
country_code <- unique(country_list$geographic_area_m49)

# Reference list of items

item_list <- ReadDatatable('item_list_for_gk', where = "measured_item_cpc != 'NA'")
item_list[, flag_i := grepl('i', measured_item_cpc)]
item_list[, flag_b := grepl('b', measured_item_cpc)]
item_list <- item_list[!(flag_i == TRUE | flag_b == TRUE)]
item_code <- unique(item_list$measured_item_cpc)

## Get data

# Production data
prodKey = DatasetKey(
  domain = 'agriculture',
  dataset = 'aproduction',
  dimensions = list(
    Dimension(name = "geographicAreaM49",
              keys = country_code),
    Dimension(name = "measuredElement", 
              keys = '5510'),
    Dimension(name = "measuredItemCPC",
              keys = item_code),
    Dimension(name = "timePointYears", 
              keys = as.character(min_year:max_year))
  )
)

productionData <- GetData(prodKey, flags = FALSE)
setnames(productionData, 'Value', 'production')
productionData[, faoAreaCode := m492fs(geographicAreaM49)]

# Price data

priceKey = DatasetKey(
  domain = 'prod_prices',
  dataset = 'annual_producer_prices_validated',
  dimensions = list(
    Dimension(name = "geographicAreaM49",
              keys = country_code),
    Dimension(name = "measuredElement", 
              keys = '5531'),
    Dimension(name = "measuredItemCPC",
              keys = item_code),
    Dimension(name = "timePointYears", 
              keys = as.character(min_year:max_year))
    
  )
)

priceData = GetData(
  priceKey, flags = FALSE)

setnames(priceData, 'Value', 'price')
# priceData <- nameData('prod_prices', 'prod_prices_annual', priceData)

## Merge production and price data 

prod_price_data <- merge(productionData, 
                         priceData[, mget(c('geographicAreaM49', 'measuredItemCPC', 'timePointYears', 'price'))],
                         by = c('geographicAreaM49', 'measuredItemCPC', 'timePointYears'),
                         all.x = T)

## Just select the countries/commodities that have data for Production and Price over the 
## time_range.

prod_price_data <- na.omit(prod_price_data)
data2exclude <- prod_price_data[timePointYears %in% time_range, .N, 
                                c('geographicAreaM49', 'measuredItemCPC')][N < 3]

if(nrow(data2exclude) > 0) {

  for(i in 1:nrow(data2exclude)) {
    prod_price_data <- prod_price_data[!(geographicAreaM49 == data2exclude$geographicAreaM49[i] & 
                                           measuredItemCPC == data2exclude$measuredItemCPC[i])]
  }
}

# GK
gk_results <- geary_khamis_system(countries = prod_price_data$geographicAreaM49,
                                  commodities = prod_price_data$measuredItemCPC,
                                  prices = prod_price_data$price,
                                  qtds = prod_price_data$production,
                                  year = prod_price_data$timePointYears,
                                  id_country_reference = reference_country)

ppp <- gk_results$PPP
setnames(ppp, old = c('country_currency_j',  'year_', 'PPP'),
         new = c('geographicAreaM49', 'timePointYears', 'Value'))

ppp[, measuredElement := '6149']
ppp <- ppp[!(is.na(Value) | is.nan(Value))]
ppp[, flag_obs_status_v2 := 'E']
ppp[, flagMethod := 'e']

setcolorder(ppp, c('geographicAreaM49', 'measuredElement', 'timePointYears', 
                   'Value', 'flag_obs_status_v2', 'flagMethod'))

# int_dollar
int_dollar <- gk_results$International_Dollar_Price
setnames(int_dollar, old = c('commodity_i',  'year_', 'P'),
         new = c('measuredItemCPC', 'timePointYears', 'Value'))

int_dollar[, measuredElement := '5533']
int_dollar <- int_dollar[!(is.na(Value) | is.nan(Value))]

## Output/Input item
input_output_item <- ReadDatatable('input_output_items_gk')

# Merge between input_output_item and international_price_Pi_average
output_item_list <- merge(input_output_item, int_dollar, 
                          by.x = 'input_measured_item_cpc', by.y = 'measuredItemCPC', all.x = T)

output_item_list[, Value := Value * as.numeric(tcf)/100]
output_item_list[, c('input_measured_item_cpc', 'output_fcl_code', 'output_fcl_item_desc',
                     'input_fcl_code','input_fcl_item_desc', 'tcf') := NULL]
setnames(output_item_list, 'output_measured_item_cpc', 'measuredItemCPC')
output_item_list <- output_item_list[!is.na(Value)]

# Add the output items
int_dollar <- rbind(int_dollar, output_item_list)
int_dollar[, flag_obs_status_v2 := 'E']
int_dollar[, flagMethod := 'e']

setcolorder(int_dollar, c('measuredItemCPC',  'measuredElement', 'timePointYears',
                          'Value', 'flag_obs_status_v2', 'flagMethod'))

# Calculate average international dollar
average_int_dollar <- int_dollar[timePointYears %in% time_range , list(Value = mean(Value)),
           by=list(measuredItemCPC)]

average_int_dollar[, timePointYears := base_year]
average_int_dollar[, flag_obs_status_v2 := 'E']
average_int_dollar[, flagMethod := 'e']
average_int_dollar[, measuredElement := '5540']

setcolorder(average_int_dollar, c('measuredItemCPC',  'measuredElement', 'timePointYears',
                          'Value', 'flag_obs_status_v2', 'flagMethod'))

# rbind

int_dollar <- rbind(int_dollar, average_int_dollar)

## Save data

# International Dollar

if(dataset_ == 'international_dollar_prices') {
  
  save = SaveData(domain = "prod_prices", dataset = "international_dollar_prices", 
                             data = int_dollar, waitTimeout = 1800)
} else {
  save = SaveData(domain = "prod_prices", dataset = "purchasing_power_parities", 
                      data = ppp, waitTimeout = 1800)
}

paste0("Geary-Khamis completed successfully!!! ",
       save$inserted, " observations written, ",
       save$ignored, " weren't updated, ",
       save$discarded, " had problems.")