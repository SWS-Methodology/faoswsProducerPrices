##' Geary-Khamis system
##' 
##' This function calculates the International Dollar Price of commodities and the
##' Purchasing Power Parity (PPP) of countries through the Geary-Khamis system.
##' 
##' @param countries A vector containing the countries. It can be codes or names.
##' @param commodities A vector containing the commodities. It can be codes or names.
##' @param prices A numeric vector containing the price of the commodity.
##' @param qtds A numeric vector containing the quantity produced.
##' @param year A vector containing the years.
##' @param initial_ppp Numeric vector containing PPP. A default vector is 1 to all countries.
##' @param id_country_reference The code or name of a country to be the reference one.
##' @param n_round The number of significant decimals to compare two values. The default is 10.
##' 
##' @return A list with Purchasing Power Parity (PPP), International Dollar Price and 
##' the number of iteractions until the process converge.
##' 
##' @export
##'

geary_khamis_system <- function(countries, commodities, prices, qtds, year, initial_ppp = 1,
                                           id_country_reference, n_round = 10) {
  
  # creating data.table
  data <- data.table(country_currency_j = countries, # vector of countries
                     commodity_i = commodities, # vector of commodities
                     price_i_j = prices, # vector of prices
                     qtd_i_j = qtds, # vector of qtds
                     year_ = year) # vector of PPP
  
  # if one of the two columns are missing, it's not possible to use that row. Then
  # production and price will be assigned to NA.
  data[is.na(price_i_j) | is.na(qtd_i_j), `:=` (price_i_j = NA,
                                                qtd_i_j = NA)]
  
  setkey(data, year_, country_currency_j, commodity_i)
  
  # set up intial PPP
  data[, PPP := initial_ppp]
  
  n_run <<- 0
  done = FALSE
  
  while(!done) {
    
    n_run <<- n_run + 1
    if(n_run > length(unique(data$year_)) * 10) {
      stop("The algorithm does not convert. Please choose another set of parameters.")
    }
    # print(n_run)
    # flush.console()
    
    # Calc International Dollar Price
    data[, P := sum(price_i_j/PPP * qtd_i_j, na.rm = T)/sum(qtd_i_j, na.rm = T),
         by = c('year_', 'commodity_i')]
    
    # Previous data
    data_prev <- copy(data) 
    
    # Calc Purchasng Power Parity
    data[, PPP := sum(price_i_j * qtd_i_j, na.rm = T)/sum(P * qtd_i_j, na.rm = T), 
         by = list(year_, country_currency_j)]
    
    # Standard PPP based on the reference country 
    data[, PPP := PPP / unique(PPP[country_currency_j == id_country_reference]), by = "year_"]
    
    # Check whether PPP has changed or not
    if (
      all(
        round(unique(data[, PPP, by = c('country_currency_j', 'year_')])[, PPP], n_round) == 
        round(unique(data_prev[, PPP, by = c('country_currency_j', 'year_')])[, PPP], n_round), 
        na.rm = TRUE)
    )
    {
      done = TRUE
    }
  }
  return(list(PPP = unique(data[, mget(c('country_currency_j', 'year_', 'PPP'))], by = c('country_currency_j', 'year_')), 
              International_Dollar_Price = unique(data[, mget(c('commodity_i', 'year_', 'P'))], by = c('commodity_i', 'year_')), 
              Number_run = n_run))
}
