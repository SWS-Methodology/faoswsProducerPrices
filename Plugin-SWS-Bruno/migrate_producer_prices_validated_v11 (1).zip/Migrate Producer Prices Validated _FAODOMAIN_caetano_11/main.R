# This script will read the validated data up to 2017 from the Input System (it is stored in the Datatables)
# and save to the dataset Annual Producer Prices (Validated) or to the Monthly Producer Prices (Preparation).

library(faosws)
library(faoswsUtil)
library(data.table)
library(faoswsFlag)

if(CheckDebug()){
  
  library(faoswsModules)
  sett <- ReadSettings("modules/migrate_validated_data/sws.yml")
  
  SetClientFiles(sett$certdir)
  GetTestEnvironment(sett$server, sett$token)
  files = dir("R", full.names = TRUE)
  invisible(sapply(files, source))
}

# Parameters:
kind_dataset <- swsContext.computationParams$dataset_migration
min_year <- swsContext.computationParams$min_year
max_year <- swsContext.computationParams$max_year

# Conditions:
if(kind_dataset == 'annual' & 
   swsContext.datasets[[1]]@dataset != 'annual_producer_prices_validated') {
  stop('The annual producer prices data must be saved in the Annual Producer Prices (Validated) dataset.')
}

if(kind_dataset == 'monthly' & 
   swsContext.datasets[[1]]@dataset != 'monthly_producer_prices_prep') {
  stop('The monthly producer prices data must be saved in the Monthly Producer Prices (Preparation) dataset.')
}

## Get the validated data
if(kind_dataset == 'annual') {
  
  validated_data <- ReadDatatable('producer_prices_validated_data_up_to_2017', 
                                  where = paste0("data_type = 'annual' AND data_year between ", " '", 
                                                 min_year, "'", " and ", " '", max_year,  "'"))
  
  setnames(validated_data, 'data_year', 'timePointYears')
  
} else {
  
  validated_data <- ReadDatatable('producer_prices_validated_data_up_to_2017', 
                                  where = "data_type = 'monthly'")
  
  validated_data[, timePointYears := substr(data_year, 1, 4)]
  validated_data[, month := substr(data_year, 5, 6)]
  validated_data <- validated_data[timePointYears %in% as.character(min_year:max_year)]
  validated_data[, data_year := NULL]
}

# Exclude popcorn (fcl 68) because it is mapped to maize (cpc 0112). Avoid conflicts. Only Mexico has data for it.
validated_data <- validated_data[fk_data_item_code_item != '68']

# Read the mapping flag table

flag_mapping <- ReadDatatable('mapping_input_system_flag_2_sws')

# Merge flags
validated_data_mapped <- merge(validated_data, flag_mapping, 
                                           by.x = 'fk_data_symbol_code_symbol', by.y = 'input_system_flag',
                                           all.x = T)

# Countries to M49
validated_data_mapped[, geographicAreaM49 := fs2m49(as.character(fk_data_area_code_area))]

# Items to CPC
validated_data_mapped[, measuredItemCPC := fcl2cpc(formatC(as.numeric(fk_data_item_code_item), width = 4,
                                                                       flag = "0"))]

validated_data_mapped <- validated_data_mapped[!(fk_data_symbol_code_symbol %in% c('ATS', 'EUR'))]

# Select the needed columns

if(kind_dataset == 'annual') {

  data <- validated_data_mapped[, mget(c('geographicAreaM49', 'measuredItemCPC', 
                                         'fk_data_element_code_element', 'timePointYears',
                                         'value', 'flag_observation_status', 
                                         'flag_method', 'comments_2_metadata'))]
  
  setnames(data, old = c('fk_data_element_code_element', 'value', 'flag_observation_status', 
                                   'flag_method', 'comments_2_metadata'),
           new = c('measuredElement', 'Value', 'flag_obs_status_v2',
                   'flagMethod', 'Metadata_Value'))
} else {

  data <- validated_data_mapped[, mget(c('geographicAreaM49', 'measuredItemCPC', 
                                         'fk_data_element_code_element', 'timePointYears',
                                         'month', 'value', 'flag_observation_status', 
                                         'flag_method', 'comments_2_metadata'))]
  
  setnames(data, old = c('fk_data_element_code_element', 
                         'value', 'flag_observation_status', 
                         'flag_method', 'comments_2_metadata'),
           new = c('measuredElement', 'Value', 'flag_obs_status_v2',
                   'flagMethod', 'Metadata_Value'))
  
  mapping_table_months <- data.table(month = c(as.character(1:12)),
                            timePointMonths = c(7001:7012))
  data <- merge(data, mapping_table_months, by = 'month')
  data[, month := NULL]
}


# The items that contain 'i' or 'b' cannot be saved to SWS. 
data[, item_b := grepl('b', measuredItemCPC)]
data[, item_i := grepl('i', measuredItemCPC)]
data <- data[item_i == FALSE & item_b == FALSE]
data[, c('item_i', 'item_b') := NULL]

# Transform class
data[, Value := as.numeric(Value)]

# Prepare data and metadata to save

data2save <- copy(data)
data2save <- data2save[, Metadata_Value := NULL]
data2save <- na.omit(data2save)

metadata2save <- copy(data)
metadata2save <- metadata2save[, `:=` (Metadata = 'GENERAL',
                                        Metadata_Element = 'COMMENT',
                                        Metadata_Language = 'en')]
metadata2save <- na.omit(metadata2save)
metadata2save[, Value := NULL]

# Save

save <- SaveData(domain = "prod_prices", dataset = swsContext.datasets[[1]]@dataset, 
                data = data2save, metadata = metadata2save, waitTimeout = 100000)

paste0("Migrate Producer Prices Validated completed successfully!!! ",
       save$inserted, " observations written, ",
       save$ignored, " weren't updated, ",
       save$discarded, " had problems.")
